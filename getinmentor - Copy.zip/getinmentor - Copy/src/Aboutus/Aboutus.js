import "./aboutus.css";
import Header from "../header/header.js"
import Footer from "../footer/footer.js"

export default function Aboutus() {
    return (
        <div>
            <div>
                <Header />
            </div>
            <section className="aboutus">
            <h2> Hi Have A Look About Us...!</h2>
                <video width="90%" height="500px" controls>
                    <source src="./videos/Getinmentor.mp4" type="video/mp4" />
                </video>
            </section>
            <section>
                <h2>Trainers Details</h2>
                <div className="trainer-det">
                    <div className="row profile">
                        <div className="col-4">
                            <img className="t-img" src="./images/Chaitanya.png" alt="trainer_img"/>
                        </div>
                        <div className="col-8">
                            <h3>Chaitanya</h3>
                        </div>
                    </div>
                    <div className="row profile">
                        <div className="col-4">
                        <img className="t-img" src="./images/Abhishek.png" alt="trainer_img"/>
                        </div>
                        <div className="col-8">
                            <h3>Abhishek</h3>
                        </div>
                    </div>
                    <div className="row profile">
                        <div className="col-4">
                        <img className="t-img" src="./images/Tharani.png" alt="trainer_img"/>
                        </div>
                        <div className="col-8">
                            <h3>Tharani</h3>
                        </div>
                    </div>
                </div>
            </section>
            <Footer />
        </div>
    )
}