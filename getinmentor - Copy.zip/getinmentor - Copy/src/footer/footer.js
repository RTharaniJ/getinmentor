import "./footer.css";
// import ReactDOM from 'react-dom'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import Nav from 'react-bootstrap/Nav';


export default function Footer(){
    return(
        <div >
             <Nav className="footer">
                <Nav.Item className="foo_list">
                    <Nav.Link className="icon" href="#" >
                    <FontAwesomeIcon icon="fa-brands fa-facebook" />
                    <span>Facebook</span>
                    </Nav.Link>
                </Nav.Item>
                <Nav.Item className="foo_list">
                    <Nav.Link className="icon" href="#" > 
                    <span>X</span>
                    <FontAwesomeIcon icon="fa-solid fa-x" />

                    </Nav.Link>
                </Nav.Item>
                <Nav.Item className="foo_list">
                    <Nav.Link className="icon" href="#" >
                    <span>LinkedIn</span>
                    <FontAwesomeIcon icon="fa-brands fa-facebook" />
                    </Nav.Link>
                </Nav.Item>
                <Nav.Item className="foo_list">
                    <Nav.Link className="icon" href="#" >
                    <span>Instagram</span>
                    <FontAwesomeIcon icon="fa-brands fa-facebook" />
                    </Nav.Link>
                </Nav.Item>
                <Nav.Item className="foo_list">
                    <Nav.Link className="icon" href="#" >
               
                    <FontAwesomeIcon icon="fa-regular fa-copyright" />
                    <span>CopyRight</span>
                    </Nav.Link>
                </Nav.Item>
            </Nav>
        </div>
    );
}
