import Button from 'react-bootstrap/Button';
import Nav from 'react-bootstrap/Nav';
import './header.css';

export default function Header() {
    return (
        <div>
            <div className='navigations'>

                <Nav>
                    <Nav.Item className="logo-line">
                        <Nav.Link href="/logo" >
                            <img className="logo" src="./images/logo.png" alt="" />

                        </Nav.Link>
                    </Nav.Item>
                </Nav>

                <Nav className="nav-bar" >
                    <Nav.Item className="logo-line">
                        <div className='search-bar'>
                            <input type="text" id="search" class="search" placeholder="Search" />
                            <Button eventKey="link-1">search</Button>
                        </div>
                    </Nav.Item>
                    <Nav.Item className="logo-line log">
                        <Nav.Link eventKey="disabled" disabled>

                            <Button variant="light">Login</Button>


                        </Nav.Link>
                    </Nav.Item>

                    <Nav.Item className="logo-line log">
                        <Nav.Link eventKey="disabled" disabled>
                            <Button variant="success">Register</Button>
                        </Nav.Link>
                    </Nav.Item>
                </Nav>

            </div>
            <div className='second_navigation'>
          
    <Nav className='nav2' variant="tabs" fill >
      <Nav.Item className='nav2'>
        <Nav.Link href="/home">Home</Nav.Link>
      </Nav.Item >
      <Nav.Item className='nav2'>
        <Nav.Link href="/aboutus">About Us</Nav.Link>
      </Nav.Item>
      <Nav.Item className='nav2'>
        <Nav.Link eventKey="disabled" disabled>
          Blogs
        </Nav.Link>
      </Nav.Item>
    </Nav>
  
            </div>



        </div>
    );
}

