import "./home.css";
import Carousel from 'react-bootstrap/Carousel';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Header from "../header/header.js"
import Footer from "../footer/footer.js"


export default function Home() {

    const handleEnrollClick = () => {
        window.open("https://www.paypal.com/ncp/payment/DTSN7926BXRU6", "_blank");
    };
    return (

        <div>

            <div>
                <Header />
            </div>
            <section className="carousel" >

                <Carousel>
                    <Carousel.Item>
                        {/* <ExampleCarouselImage text="First slide" /> */}
                        <img className="carouselimage" src="./images/carousel1.png" alt="siteexclusives" />

                        <Carousel.Caption className="caption-carousel">
                            <h3>First slide label</h3>
                            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                        </Carousel.Caption>
                    </Carousel.Item>
                    <Carousel.Item>
                        {/* <ExampleCarouselImage text="Second slide" /> */}
                        <img className="carouselimage" src="./images/carousel2.png" alt="siteexclusives" />
                        <Carousel.Caption className="caption-carousel">
                            <h3>Second slide label</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        </Carousel.Caption>
                    </Carousel.Item>
                    <Carousel.Item>
                        {/* <ExampleCarouselImage text="Third slide" /> */}
                        <img className="carouselimage" src="./images/carousel3.png" alt="siteexclusives" />
                        <Carousel.Caption className="caption-carousel">
                            <h3>Third slide label</h3>
                            <p>
                                Praesent commodo cursus magna, vel scelerisque nisl consectetur.
                            </p>
                        </Carousel.Caption>
                    </Carousel.Item>
                </Carousel>


            </section>

            <section >
                <h2 className="title2">Programs and Certifications</h2>
                <div className="course-list">
                    <Card className="card" >
                        <Card.Img variant="top" src="./images/output.png" alt="courseimg" />

                        <Card.Body>
                            <Card.Title className="card_title">Card Title</Card.Title>
                            <Card.Text>
                                Some quick example text to build on the card title and make up the
                                bulk of the card's content.
                            </Card.Text>
                            <Button onClick={handleEnrollClick} variant="primary">Enroll now for just $12</Button>
                        </Card.Body>
                    </Card>
                    <Card className="card" >
                        <Card.Img variant="top" src="./images/output.png" alt="courseimg" />

                        <Card.Body>
                            <Card.Title className="card_title">Card Title</Card.Title>
                            <Card.Text>
                                Some quick example text to build on the card title and make up the
                                bulk of the card's content.
                            </Card.Text>
                            <Button variant="primary" eventKey="disabled" disabled>Enroll now for just $12</Button>
                        </Card.Body>
                    </Card>
                    <Card className="card" >
                        <Card.Img variant="top" src="./images/output.png" alt="courseimg" />

                        <Card.Body>
                            <Card.Title className="card_title">Card Title</Card.Title>
                            <Card.Text>
                                Some quick example text to build on the card title and make up the
                                bulk of the card's content.
                            </Card.Text>
                            <Button  variant="primary" eventKey="disabled" disabled>Enroll now for just $12</Button>
                        </Card.Body>
                    </Card>
                    <Card className="card" >
                        <Card.Img variant="top" src="./images/output.png" alt="courseimg" />

                        <Card.Body>
                            <Card.Title className="card_title">Card Title</Card.Title>
                            <Card.Text>
                                Some quick example text to build on the card title and make up the
                                bulk of the card's content.
                            </Card.Text>
                            <Button  variant="primary" eventKey="disabled" disabled>Enroll now for just $12</Button>
                        </Card.Body>
                    </Card>
                    <Card className="card" >
                        <Card.Img variant="top" src="./images/output.png" alt="courseimg" />

                        <Card.Body>
                            <Card.Title className="card_title">Card Title</Card.Title>
                            <Card.Text>
                                Some quick example text to build on the card title and make up the
                                bulk of the card's content.
                            </Card.Text>
                            <Button  variant="primary" eventKey="disabled" disabled>Enroll now for just $12</Button>
                        </Card.Body>
                    </Card>
                    <Card className="card" >
                        <Card.Img variant="top" src="./images/output.png" alt="courseimg" />

                        <Card.Body>
                            <Card.Title className="card_title">Card Title</Card.Title>
                            <Card.Text>
                                Some quick example text to build on the card title and make up the
                                bulk of the card's content.
                            </Card.Text>
                            <Button  variant="primary"eventKey="disabled" disabled>Enroll now for just $12</Button>
                        </Card.Body>
                    </Card>
                </div>

            </section>
            <Footer />
        </div>
    );
}

